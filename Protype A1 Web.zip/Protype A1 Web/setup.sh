#!/bin/bash

# Install Python dependencies
pip install flask flask-cors

echo "Setup complete! Run 'python app.py' to start the application."